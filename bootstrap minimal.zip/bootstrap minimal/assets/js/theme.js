function init() {
    var imgDefer = document.getElementsByTagName('img');
    for (var i=0; i<imgDefer.length; i++) {
    if(imgDefer[i].getAttribute('data-src')) {
    imgDefer[i].setAttribute('src',imgDefer[i].getAttribute('data-src'));
    } } }
    window.onload = init;


jQuery(function ($) {
    "use strict";


    // Bootstrap carousel animations Function...
    function bsCrslAnimate() {
        function doAnimations(elems) {
            var animEndEv = 'webkitAnimationEnd animationend';
            elems.each(function () {
                var $this = $(this),
                    $animationDelay = $this.data('anim-delay'),
                    $animationType = $this.data('anim');
                $this.css({'animationDelay': $animationDelay});
                $this.addClass($animationType).one(animEndEv, function () {
                    $this.removeClass($animationType);
                });
            });
        }

        var $myCarousel = $('.crsl-animate'),
            $firstAnimatingElems = $myCarousel.find('.item:first').find("[data-anim ^= 'animated']");
        $myCarousel.carousel();
        doAnimations($firstAnimatingElems);
        $myCarousel.carousel();
        $myCarousel.on('slide.bs.carousel', function (e) {
            var $animatingElems = $(e.relatedTarget).find("[data-anim ^= 'animated']");
            doAnimations($animatingElems);
        });
    }


    // Bootstrap carousel hide controls if one item...
    function bsCarouselHideCtrls() {
        $('[data-ride="carousel"]').each(function () {
            var $carousel = $(this);
            var $items = $carousel.find('.item');
            if ($items.length > 1) {

            } else {
                $('.carousel-indicators, .crsl-ctrl', $carousel).remove();
            }
        });
    }


    // Side Slide Modal Show Hide function...

    $("[data-target='slideModal']").click(function (e) {

        e.preventDefault();

        $("#slideModal").addClass("open-smod");

        $("body, .header-wrap").css("padding-right", scBarWidth);

        $("body").addClass("sm-open");

    });


    $('.spec-col-inner').on('click', function (e) {
        e.preventDefault();
        $("#slideModal2").addClass("open-smod");
        $("body, .header-wrap").css("padding-right", scBarWidth);
        $("body").addClass("sm-open");
    });



    $('#selSpecialty').on('change', function () {
        $("#slideModal2").addClass("open-smod");
        $("body, .header-wrap").css("padding-right", scBarWidth);
        $("body").addClass("sm-open");
    });











    $('[data-toggle="slideLeft"]').on('click', function () {
        $("body").toggleClass("open-mobile-nav");
    });

    $(".slide-modal-x").click(function (e) {

        e.preventDefault();

        $(".slide-modal-outer").removeClass("open-smod");

        $("body, .header-wrap").css("padding-right", 0);

        $("body").removeClass("sm-open");

    });




    /* -------------------------------------------------------------------------
     * Window Load
     * ----------------------------------------------------------------------- */

    $(window).on('load', function () {





        setTimeout(function(){
            $('.site-preload').fadeOut('slow');
            $('body').addClass('site-loaded');
        },4000);





        setTimeout(function () {
            bsCrslAnimate();
        }, 400);

        bsCarouselHideCtrls();


    });


    /* -------------------------------------------------------------------------
     * Document Ready
     * ----------------------------------------------------------------------- */

    $(document).ready(function () {


        $("#overlay-contact-open").click(function(){
            $(".overlay-full").show();
            $("#contact-overlay").show('slide');
            
        });


        $(".close-btn").click(function(){
            $(".overlay-full").hide();
            $("#contact-overlay").hide('slide');
            
        });

        // Inline background image...
        $("[data-bg]").each(function () {
            var image = $(this).attr("data-bg");
            $(this).css({
                backgroundImage: 'url("' + image + '")',
            });
        });


        // Back to top anchor...
        $("[href='#backTop']").click(function (e) {
            e.preventDefault();
            $('html,body').animate({
                scrollTop: 0
            }, 500);
        })


// Image overly effect init =======================

// handle the mouseenter functionality
	$(".img").mouseenter(function(){
		$(this).addClass("hover");
	})
	// handle the mouseleave functionality
	.mouseleave(function(){
		$(this).removeClass("hover");
	});
$('.gallery a').simpleLightbox();







    });


    /* -------------------------------------------------------------------------
     * Window Scroll
     * ----------------------------------------------------------------------- */
    $(window).scroll(function () {

        // Write code here


    });


    /* -------------------------------------------------------------------------
     * Window Resize
     * ----------------------------------------------------------------------- */
    $(window).on('resize', function () {

        // Write your code here


    });
});